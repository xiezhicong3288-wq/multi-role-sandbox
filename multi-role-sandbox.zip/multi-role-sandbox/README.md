# multi-role-sandbox

五方专家立场对抗推演沙盘：把任一事件交给顶尖律师团队/公安/法院/当地政府/上级监督部门五个独立立场，做单角色分析或五方对抗式推演，输出《运筹决策报告》。

## 安装

放到 skills 目录（用户级 `~/.workbuddy/skills/multi-role-sandbox/` 或项目级 `.workbuddy/skills/multi-role-sandbox/`）即可，无依赖，纯提示词驱动。

## 用法

直接在对话中描述事件并说意图，例如：

- "用五方对抗推演分析【我的案子】" → 启动总控推演，输出《运筹决策报告》。
- "只从法院视角看这个案子" → 取法院角色单角色深析。
- "配合 chat-evidence 的证据产物推演" → 把 `*.anchor.json`/`*.timeline.md` 等作为底本喂入。

角色提示词与总控规则见 `references/multi_role_sandbox.md`。完整推演落地为 `*.sandbox.md`。

## 许可

保留所有权利（All Rights Reserved）。本仓库**公开仅供查阅**，未经作者书面授权，不得复制、修改、二次分发或用于任何商业/衍生用途。方法论来源：中国现行三大诉讼法、纪检监察/信访相关规定、对抗式决策推演。
